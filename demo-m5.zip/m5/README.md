# Module 5 - Creating a Hybrid Cloud via IPsec VPN to Palo Alto Firewall in AWS
This module uses Ansible to configure Amazon Web Services (AWS) infrastructure
components, as well as deploying a Palo Alto Networks (PAN) firewall and
connecting it back to a Cisco router using an Internet-based IPsec VPN.
