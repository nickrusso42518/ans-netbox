#!/bin/bash
# Print the value of ANSIBLE_VP without a newline
# Use 'export ANSIBLE_VP=<password>' to set 
echo -n $ANSIBLE_VP
