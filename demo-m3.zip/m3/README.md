# Module 3 - Configuration Management and Validation with NAPALM
This module uses NAPALM getters to collect VLAN information, then
manipulates the data so it can be used for future network validation.
