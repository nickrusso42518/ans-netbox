# Module 4 - Building and Referencing a Single Source of Truth with NetBox
This module covers configuring NetBox using Ansible by describing the
current network as NetBox objects. It also uses those newly-created NetBox
devices as a dynamic inventory source for Ansible playbooks.
